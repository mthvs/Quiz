let containerQuiz = document.getElementById('containerQuiz');
let mathButton = document.getElementById('mathButton');
let historyButton = document.getElementById('historyButton');
let menuContainer = document.getElementById('menu')
let menuButton = document.getElementById('menuButton')
let proxButton = document.getElementById('proxButton')
let perguntaAtual = 1;
let contador = 0;
let numRespostasCertas = 0;
let selectedOptionElement = null
let quiz = null;

mathButton.addEventListener('click', function(ev){
    getQuiz("Matematica")
    menuContainer.classList.add('hide')
})

historyButton.addEventListener('click', function(ev){
    getQuiz("Historia")
    menuContainer.classList.add('hide')
})

menuButton.addEventListener('click', function(ev){
    perguntaAtual = 1
    numRespostasCertas = 0;
    containerQuiz.innerHTML= ""
    menuContainer.classList.remove('hide')
    menuButton.classList.add('hide')
    proxButton.classList.add('hide')
})

proxButton.addEventListener('click', function(ev){
    perguntaAtual++
    proxButton.classList.add('hide')
    if(perguntaAtual == 4){
        proxButton.classList.add('hide')
    }
    if(contador > 0){
        numRespostasCertas++;
    }
    console.log(numRespostasCertas)
    buildQuiz()
})

function getQuiz(typeQuiz){
    var dadosQuiz = $.post('/quiz', {"typeQuiz":typeQuiz})
    dadosQuiz.done(function(Quiz){
        quiz = Quiz
        buildQuiz();
        menuButton.classList.remove('hide')
    })
}

function buildQuiz(){
    console.log(quiz)
    containerQuiz.innerHTML= ""
    contador = 0;
        const resultContainer = document.createElement('div');
        const titleQuiz = document.createElement('h1');
        titleQuiz.textContent = quiz.title;
        containerQuiz.appendChild(titleQuiz);
        
        if(perguntaAtual == 4){
            resultContainer.classList.remove('hide')
            const  parabens = document.createElement('h2')
            parabens.textContent = "!! Parabens !!"

            const resultado = document.createElement('h3')
            resultado.textContent = "Voce acertou "+ numRespostasCertas+"/3"
            
            resultContainer.appendChild(parabens)
            resultContainer.appendChild(resultado);
            console.log(parabens)
            
        }else{
            resultContainer.classList.add('hide')
        }

        quiz.perguntas.forEach(function(pergunta, indice){
            const questionContainer = document.createElement('div');
        


            if(pergunta.id != perguntaAtual){
                questionContainer.classList.add('hide')
            }else{
                questionContainer.classList.remove('hide')
            }


            const perguntaDescricao = document.createElement('h3');
            perguntaDescricao.textContent = pergunta.title;
            const OptionsPergunta = document.createElement('div');
            

            pergunta.options.forEach(function(option, indice){

                const newContainerQuestionOption = document.createElement('label')
                newContainerQuestionOption.classList.add('question-option')

                const textSpan = document.createElement('span')
                textSpan.textContent = option.text

                const radioButton = document.createElement('input')
                radioButton.id = option.id
                radioButton.setAttribute("type","radio");
                radioButton.setAttribute("name","question");
                radioButton.classList.add("hide");

                radioButton.addEventListener("change",function(e){
                    proxButton.classList.remove('hide')
                    if(selectedOptionElement != null){
                        selectedOptionElement.classList.remove('container-color-option')
                    }
                    selectedOptionElement = newContainerQuestionOption
                    newContainerQuestionOption.classList.add('container-color-option')
                    if(option.id == pergunta.resposta){
                        contador = 1
                    } else{
                        contador = 0;
                    }
   
                })

                
                newContainerQuestionOption.appendChild(radioButton)
                newContainerQuestionOption.appendChild(textSpan)
                newContainerQuestionOption.classList.add('container-option')

                OptionsPergunta.appendChild(newContainerQuestionOption);

            })
            containerQuiz.appendChild(resultContainer)
            questionContainer.appendChild(perguntaDescricao);
            questionContainer.appendChild(OptionsPergunta);
            containerQuiz.appendChild(questionContainer);
            
        })
}

