import json
from temas import Temas
from integer import Integer



with open("historyQuestion.json", encoding='utf-8') as Qh:
    history = json.load(Qh)

with open("mathQuestion.json", encoding='utf-8') as Qm:
    math = json.load(Qm)

class  Pergunta():
    def __init__(self,id, title,resposta):
        self.id = id
        self.title = title
        self.options = []
        self.resposta = resposta


    def define_options(self,respostas):
        self.options = respostas

    def to_dict(self):
        return {'id': self.id , 'title': self.title ,'options': self.Options_to_dict(), 'resposta': self.resposta}

    def Options_to_dict(self):
        List_options = []
        for option in self.options:
            List_options.append(option.to_dict())
        return List_options

    def __str__(self):
        return f'{self.id} {self.title}'


class Option():
    def __init__(self,id,text):
        self.id = id
        self.text = text

    def __str__(self):
        return f'{self.id} {self.text}'

    def to_dict(self):
        return {'id': self.id, 'text': self.text}


class Quiz():
    def __init__ (self,id,title,perguntas):
        self.id = id
        self.title = title
        self.perguntas = perguntas


    def to_dict(self):
        return {'id': self.id ,'title':self.title, 'perguntas': self.perguntas_to_dict()}

    def perguntas_to_dict(self):
        List_perguntas = []
        for pergunta in self.perguntas:
            List_perguntas.append(pergunta.to_dict())
        return List_perguntas


#Padrao Strategy usado para retornar o conteudo lido de cada jason baseado no tema.
class ContentStorageStrategy():
       
    def ReturnContentSpecifiedArq (paran):
        if paran == Temas.Matematica:
            readerfileMath = ReaderfileMath()
            return readerfileMath.ler()
        if paran == Temas.Historia: 
            readerfileHistory = ReaderfileHistory()
            return readerfileHistory.ler()


class ReaderfileQuiz(): 
    
    def __init__(self):
        self.contentFile = None,
        pass


    def ler(self):
        list_perguntas = []
        for i in self.contentFile['perguntas']:
            pergunta = Pergunta(i['id'], i['question'], i['answer_id'])
            list_options = []
            for x in i['options']:
                option = Option(x['id'], x['text'])
                list_options.append(option)
            pergunta.define_options(list_options)
            list_perguntas.append(pergunta)
        return list_perguntas



#Padrao Sigleton usado para seja possivel ler apenas uma vez o contudo presente no json, sendo assim o conteudo lido sempre sendo o mesmo.
class ReaderfileMath(ReaderfileQuiz):
    _instanse = None
    def __init__(self):
        self.contentFile = math
    
    def __new__(cls):
        if cls._instanse is None:
            cls._instanse = super().__new__(cls)
        return  cls._instanse


class ReaderfileHistory(ReaderfileQuiz):
    _instanse = None
    def __init__(self):
        self.contentFile = history
    
    def __new__(cls):
        if cls._instanse is None:
            cls._instanse = super().__new__(cls)
        return  cls._instanse



def QuizTeste(Ruser,RQuiz):
    if Ruser == RQuiz:
        print("\nParabens Voce Acertou\n")
    else:
        print("\nvoce errou\n")


def teste(self):
        for i in self.perguntas:
            print(f"\n{i}")
            for x in i.options:
                print(f"{x.id} . {x.text}")
            print("\n")
            resposta = input("qual a resposta correta? R: ")
            QuizTeste(Integer(resposta), i.resposta)




historia = Quiz(history['id'],history['title'],ContentStorageStrategy.ReturnContentSpecifiedArq(Temas.Historia))
matematica = Quiz(math['id'], math['title'], ContentStorageStrategy.ReturnContentSpecifiedArq(Temas.Matematica))

 

