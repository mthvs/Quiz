from temas import Temas
from quiz import historia, matematica 

#Padrao factory usado para separar os temas para que seja retornado apenas o tema escolhido pelo usuário
class QuizFactory():

    def Quiz(tipo):
        if tipo == Temas.Historia:
            print('estou em historia')
            return historia
        elif tipo == Temas.Matematica:
            print('estou matematica')
            return matematica
