from enum import Enum

class Temas(Enum):
    Historia = 1
    Geografia = 2
    Matematica = 3
    Mundo = 4
    Informatica = 5